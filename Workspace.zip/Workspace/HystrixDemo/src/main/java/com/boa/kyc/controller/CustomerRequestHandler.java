package com.boa.kyc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class CustomerRequestHandler {

	@Autowired
	RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "handleFallBack")
	public String handleRequest() {
		return restTemplate.exchange("http://localhost:8081/api/customer/getAllCustomers", HttpMethod.GET, null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
	}

	public String handleFallBack() {
		return restTemplate.exchange("http://localhost:8082/api/customer/getAllCustomers", HttpMethod.GET, null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
	}

	@Bean
	public RestTemplate getInstance() {
		return new RestTemplate();
	}
}
