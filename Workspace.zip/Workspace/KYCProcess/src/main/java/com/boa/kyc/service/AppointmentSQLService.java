package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.model.AppointmentSQL;
import com.boa.kyc.repo.AppointmentSqlRepo;

@Service
public class AppointmentSQLService {

	@Autowired
	private AppointmentSqlRepo appointmentSqlRepo;

	public AppointmentSQL saveAppointement(AppointmentSQL appoinment) {
		return appointmentSqlRepo.save(appoinment);
	}

	public List<AppointmentSQL> getAllAppointments() {
		return appointmentSqlRepo.findAll();
	}
}
