package com.boa.kyc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.model.Address;
import com.boa.kyc.model.Customer;
import com.boa.kyc.repo.AddressRepo;

@Service
public class AddressService {

	@Autowired
	private AddressRepo addressRepo;

	@Autowired
	private CustomerService customerService;

	public Address addAddress(int id, Address address) {
		Customer cust = customerService.getCustomerById(id);
		address.setCustomer(cust);
		return addressRepo.save(address);
	}

}
