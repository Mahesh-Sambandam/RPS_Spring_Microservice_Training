package com.boa.kyc.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.config.DBConfiguration;
import com.boa.kyc.model.Appointment;
import com.boa.kyc.model.AppointmentSQL;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/appointment")
public class AppointmentController {

	@Autowired
	private DBConfiguration dbConfiguration;

	@PostMapping("/save")
	public ResponseEntity<?> saveAppointment(@RequestBody String obj)
			throws JsonParseException, JsonMappingException, IOException {
		System.out.println(System.getProperty("dbType"));
		ObjectMapper mapper = new ObjectMapper();
		if ("MongoDB".equalsIgnoreCase(System.getProperty("dbType"))) {
			Appointment app = mapper.readValue(obj, Appointment.class);
			return ResponseEntity.ok(dbConfiguration.getNoSQLInstance().saveAppointement(app));
		} else {
			AppointmentSQL app = mapper.readValue(obj, AppointmentSQL.class);
			return ResponseEntity.ok(dbConfiguration.getSQLInstance().saveAppointement(app));
		}

	}

	@GetMapping("/all")
	public ResponseEntity<List<?>> getAllAppointments() {
		if ("MongoDB".equalsIgnoreCase(System.getProperty("dbType"))) {
			return ResponseEntity.ok(dbConfiguration.getNoSQLInstance().getAllAppointments());
		} else {
			return ResponseEntity.ok(dbConfiguration.getSQLInstance().getAllAppointments());
		}

	}
}
