package com.boa.kyc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.model.Address;
import com.boa.kyc.service.AddressService;

@RestController
@RequestMapping("/api/address")
public class AddressController {

	@Autowired
	private AddressService addressService;

	@PostMapping("/save/{id}")
	public ResponseEntity<Address> saveAddress(@PathVariable("id") int id, @RequestBody Address address) {
		return ResponseEntity.ok(addressService.addAddress(id, address));
	}

}
