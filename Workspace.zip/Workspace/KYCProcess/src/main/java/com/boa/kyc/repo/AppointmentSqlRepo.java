package com.boa.kyc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.kyc.model.AppointmentSQL;

public interface AppointmentSqlRepo extends JpaRepository<AppointmentSQL, Integer> {

}
