package com.boa.kyc.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.boa.kyc.config.DBConfiguration;
import com.boa.kyc.model.Appointment;
import com.boa.kyc.model.AppointmentSQL;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Controller
public class AppointmentCController {
	@Autowired
	private DBConfiguration dbConfiguration;

	@PostMapping("/addAppointment")
	public String saveAppointment(@ModelAttribute Appointment obj1, @ModelAttribute AppointmentSQL obj2)
			throws JsonParseException, JsonMappingException, IOException {
		System.out.println(System.getProperty("dbType"));
		if ("MongoDB".equalsIgnoreCase(System.getProperty("dbType"))) {
			dbConfiguration.getNoSQLInstance().saveAppointement(obj1);
		} else {
			dbConfiguration.getSQLInstance().saveAppointement(obj2);
		}
		return "redirect:getAllAppointments";

	}

	@GetMapping("/getAllAppointments")
	public String getAllAppointments(Model model) {
		if ("MongoDB".equalsIgnoreCase(System.getProperty("dbType"))) {
			model.addAttribute("appointmentList", dbConfiguration.getNoSQLInstance().getAllAppointments());

		} else {
			model.addAttribute("appointmentList", dbConfiguration.getSQLInstance().getAllAppointments());
		}

		return "home";
	}

}
