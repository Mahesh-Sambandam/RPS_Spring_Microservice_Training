package com.boa.kyc.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boa.kyc.model.Customer;


public interface CustomerRepo extends JpaRepository<Customer, Integer> {

	@Modifying(clearAutomatically = true)
	@Query(value = "select * from Customer  where firstName=:fname", nativeQuery = true)
	List<Customer> findByName(@Param("fname") String name);
}
